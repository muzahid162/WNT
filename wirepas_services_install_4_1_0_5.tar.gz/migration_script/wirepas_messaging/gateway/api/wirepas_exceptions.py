"""
    Wirepas exceptions
    ==================

"""


class GatewayAPIParsingException(Exception):
    """
    Wirepas Gateway API generic Exception
    """
