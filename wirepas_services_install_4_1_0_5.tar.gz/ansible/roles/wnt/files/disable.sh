#!/usr/bin/env bash

source ~/.profile;
docker-compose down;

