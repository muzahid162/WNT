# Wirepas Oy 2018
#!/usr/bin/env bash

source ~/.profile;
docker-compose down;
